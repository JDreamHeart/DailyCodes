--加载framework代码
-- Author: Your Name
-- Date: 2017-05-17 11:46:20
--
print("加载BYFramework");
require("BYFramework.core.object");
require("BYFramework.lib.StringLib");
import(".lib.MathLib")
import(".lib.TableLib")
import(".tools.functions")
import(".tools.dump")
import(".tools.dumpToFile")
import(".tools.profiler")


print("加载BYFramework----结束");