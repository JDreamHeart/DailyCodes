--[[
-- 主要讲解lua性能测试


]]


package.path = package.path .. ";../../?.lua;"
require("BYFramework._load")


local test1 = function( ... )
	profiler = newProfiler()
 	profiler:start()
 	local str = "";
 	for i = 1, 1 do
 		str = str .. i .. ",";
    end
    print(str)
    local outfile = io.open( "profile.txt", "w+" )
    profiler:report( outfile )
    outfile:close()
end

function shuffleCards()
    local cardList = createCards();
    printCards(cardList)
    cardList = TableUtil.randomList(cardList)
    print("")
    printCards(cardList)
end


local test2 = function( ... )
	profiler = newProfiler()
 	profiler:start()
 	local str = {};
 	for i = 1, 100000 do
 		table.insert(str,i)
    end
    str = table.concat(str,",")
    print(str)
    local outfile = io.open( "profile.txt", "w+" )
    profiler:report( outfile )
    outfile:close()
end

local function main()
	test1()
	-- test2()
end

main();