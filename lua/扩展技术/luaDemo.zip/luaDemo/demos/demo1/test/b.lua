--
-- Author: Your Name
-- Date: 2017-06-15 10:33:42
--
local a = require("test.a")
dump(a)

module "test"

xxxxxx = 1