--
-- Author: Your Name
-- Date: 2017-06-15 10:33:22
--
local a = {
}

a.a = 1;

function a.xxx()
end

return a