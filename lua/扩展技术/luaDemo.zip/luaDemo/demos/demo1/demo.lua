--[[
-- 主要讲解packgae.load
用require函数只能加载一次,因为它的特性是:
1、require函数会搜索目录加载文件
2、require会判断是否文件已经加载避免重复加载同一文件。

-- local coord = require("test/coord")
]]

---设置加载路径
package.path = package.path .. ";../../?.lua;"

require("BYFramework._load")

require("dump")

print(package.path)

-- local a = require("test.a")
-- a:xxx()


-- print(dump(package.loaded["test/a"]))

local a = "A";
local b = "b";

-- function string.trim(str, char)
-- 	if (char == '' or char == nil) then
-- 		char = '%s'
-- 	end

-- 	local trimmed = string.gsub(str, '^' .. char .. '*(.-)' .. char .. '*$', '%1')
-- 	return trimmed
-- end

	profiler = newProfiler("call")
 	profiler:start()
 

local char = "%["
print(string.trim("[[[word", char))
print(string.gsub("[[[word", '^' .. char .. '*(.-)' .. char .. '*$', '%1'))

    local outfile = io.open( "profile.txt", "w+" )
    profiler:report( outfile )
    outfile:close()

