--[[
-- 主要讲解不定参数


]]

local M = {};

function M:setCallBack(fn)
	self.fn = fn;
end

function M:doCallBack()
	local time = os.time();
	local ret = self.fn(time)
	print(ret)
end

function M.spring( factor )
    local _factor = factor or 0.4
    return function ( f )
        return math.pow(2,-10*f) * math.sin((f- _factor / 4 ) * (2 * math.pi) / _factor)+1
    end
end


local function test()
	local anim 	= g_AnimManager:play(AnimConfig.chi,{queue = true})
	anim.mSwfAnim:setNodeCallback(nodeName, obj, func)
	local anim2 = g_AnimManager:play(AnimConfig.peng,{queue = true})
	
	-- local play = anim2.play
	-- anim2.play = function( ... )
	-- 	play()
	-- 	self.mSwfAnim:setNodeCallback(nodeName, obj, func)
	-- end
	-- local a = setPos()
	-- local old = Clock.instance():schedule_once
	-- Clock.instance().schedule_once =function( ... )
	-- 	old()
	-- 	num++
	-- end
	
	
end

	-- local function spring(t)
	-- 	return function(f)
	-- 		return f*t;
	-- 	end
	-- end
	-- M:setCallBack(spring(3))

local function main( ... )

	-- local args = {...}
	-- for i,v in ipairs(args) do
	-- 	print(i,v)
	-- end
	-- local unpack(args)
	local function spring(t)
		return function(f)
			return f*t;
		end
	end
	M:setCallBack(spring(2))

	M:doCallBack()

end

main(1,"212",{213},123);