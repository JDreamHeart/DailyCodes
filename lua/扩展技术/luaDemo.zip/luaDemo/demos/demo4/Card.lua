local Card = {};

local _typeMap = {
	[0] = "方块";
	[1] = "梅花";
	[2] = "红桃";
	[3] = "黑桃";
}

local _valueMap = {
	[3] = "3";
	[4] = "4";
	[5] = "5";
	[6] = "6";
	[7] = "7";
	[8] = "8";
	[9] = "9";
	[10] = "10";
	[11] = "J",
	[12] = "Q",
	[13] = "K",
	[14] = "A",
	[15] = "2",
	[16] = "小王",
	[17] = "大王",
}

local M = {}

local mt = {};
---比较
mt.__eq = function (c1, c2)
	-- return c1.cardByte == c2.cardByte; 
	return c1.cardValue == c2.cardValue; 
end
---减法
mt.__sub = function (c1, c2) 
	return c1.cardValue - c2.cardValue; 
end
---加法
mt.__add = function (c1, c2) 
	return c1.cardValue + c2.cardValue; 
end

mt.__tostring = function (t)
	if t.cardValue < 16 then
		return _typeMap[t.cardType].._valueMap[t.cardValue];
	else
		return _valueMap[t.cardValue];
	end
end

mt.__index = M;

function Card.new(byte)
	local card = {};
	card.cardByte = byte; --byte值 唯一值
	card.cardType = bit.brshift(byte, 4); --牌的类型
	card.cardValue = bit.band(byte, 0x0f);--牌值

	if card.cardValue < 3 then
		card.cardValue = card.cardValue + 13;
	elseif card.cardValue > 13 then
		card.cardValue = card.cardValue + 2;
	end

	setmetatable(card, mt);

	return card;
end

return Card;