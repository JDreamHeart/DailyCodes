--[[
-- 主要讲解lua元表，call


]]
package.path = package.path .. ";../../?.lua;"
require("BYFramework._load")


local DAO = {}
local meta = {
	__call = function(self,params)
		params = checktable(params)
		for k,v in pairs(params) do
			print(k,v)
			self[k] = v;
		end
		return self;
	end
}

setmetatable(DAO, meta)
local function main( ... )
	DAO{a = 1}
	dump(DAO)

end

main();