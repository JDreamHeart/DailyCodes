--[[
-- 主要讲解lua元表，tostring add sub eq


]]
package.path = package.path .. ";../../?.lua;"
require("BYFramework._load")
require("bit")
bit.brshift = bit.rshift

local Card = require("Card")

function randomList(t, num)
    local randomList = { }
    num = num or #t;

    if num > #t then
        num = #t;
    end

    local rangeList = { };
    for i = 1, num do
        rangeList[i] = t[i]
    end

    for i = 1, num do
        local index = math.random(i, #rangeList);
        rangeList[i], rangeList[index] = rangeList[index], rangeList[i];
        randomList[i] = rangeList[i];
    end

    return randomList;
end

function createCards()
	local cards = {}
	for i = 0, 3 do
		for j = 1, 13 do
			local x = bit.lshift(i, 4);
			local value = bit.bor(x, j);
			table.insert(cards, value);
		end
	end
	table.insert(cards, 0x4e); -- 大小王
	table.insert(cards, 0x4f);

	local cardList = {};

	for i, cardByte in ipairs(cards) do
		local c = Card.new(cardByte)
		table.insert(cardList,c);
	end
	return cardList;
end

local test2 = function( ... )
	profiler = newProfiler("call")
 	profiler:start()
 
 	for i = 1, 1000 do
 		local cards = createCards()
 		randomList(cards)
    end

    local outfile = io.open( "profile.txt", "w+" )
    profiler:report( outfile )
    outfile:close()
end

local function main( ... )
	test2()

end

main();