--[[
-- 主要讲解lua元表，index,newindex


]]


package.path = package.path .. ";../../?.lua;"
require("BYFramework._load")


function createTable()
    local proxy = {}
    local object = {};
    local mt = {
            __index = object,
            __newindex = function(t,k,v)             
                object[k] = v;
                if k == "money" then
                    print("有人尝试修改money")
                    print(debug.traceback())
                end
            end
        }
    setmetatable(proxy,mt)
    return proxy
end

---数据追踪
local function test1()
	g_UserInfo = createTable();
	dump(g_UserInfo);
	g_UserInfo.nick = "1111111";

	g_UserInfo.exp  = 1;
	dump(g_UserInfo);
	print(g_UserInfo.nick)

	g_UserInfo.money = 1;

    g_UserInfo.xxx =2
end



local disabledKey = function(obj,keys)

    local oldMeta = getmetatable(obj)

    if oldMeta == nil then
        oldMeta = {};
    end

    if oldMeta.__index == nil then
        oldMeta.__index = {};
    end

    local object = oldMeta.__index;
	for k,v in pairs(keys) do
		object[k] = obj[k];
		obj[k] = nil;
	end
 
    -- oldMeta.__index = function(t,k)
    --     if keys[k] then
    --         -- error("你没权限访问" .. k)
    --     end
    --     return object[k]
    -- end



    oldMeta.__newindex = function(t,k,v)
        if keys[k]  then
            if type(v) ~= "table" then
                error("你没权限访问" .. k)
            elseif v.isUpdate ~= true then
                error("你没权限访问" .. k)
            else
                object[k] = v.value;
            end
        else
            object[k] = v;
        end
        
    end

    
    -- local mt = {
    --         __index = function(t,k,v)
    --         	if keys[k] then
    --             	error("你没权限访问" .. k)
    --             end
    --         	return oldMeta[k]
    --         end,
    --         __newindex = function(t,k,v)             
    --             object[k] = v;
    --             if keys[k] then
    --             	error("你没权限访问" .. k)
    --             end
    --         end
    --     }
    setmetatable(obj,oldMeta)    
end

---禁止直接访问
local function test2()
	local UserInfo = class();
	function UserInfo:ctor( ... )
		self.money = 0;
		self.level = 0;
		self.nick  = "";
		self.exp  = 0;
	end

    function UserInfo:setMoney(money)
        self.money = {isUpdate = true, value = money};
    end

	
    local Player = class(UserInfo)

   local Player2 = class(Player)
    local u = new(Player2)
	-- u.money = 1;
	-- print(u.money)
    
	disabledKey(u,{money = true})
    u:setMoney(100)
	dump(u.money)
	-- u.money = 3;
    delete(u)
	-- print(u.money)
end



local function main( ... )

    test2()

end

main()