--
-- Author: Your Name
-- Date: 2017-06-15 10:29:48
--

---设置加载路径
package.path = package.path .. ";../?.lua;"

require("BYFramework._load")

-- local TUI = class()
-- function TUI:ctor(a)
-- 	self.useList = a;

-- 	local handler = function(obj,methods)
-- 		local c = 1
-- 		local func = function(...)
-- 			methods(obj)
-- 		end
-- 		return func
-- 	end

-- 	self.on_menuitem_click = handler(self,self.a)
-- 	self.on_menuitem_click()
-- end


-- -- local b = self.xxx;
-- function TUI:a(a)
-- 	dump(self.useList)
-- 	dump(a)
	
-- end

-- local obj = new(TUI,13);
-- -- obj:a(1)
-- local func = obj.a
-- func(obj,1)
-- print(b)
-- print(c)

local BehaviorBase = {}
function BehaviorBase:getOnceOperationSettle(object,param)
	print(self)
	print(object)
	print(param)
end
local StateBase = {}

function StateBase:bind(methodName ,method)

    local newMethod = function(...)
        return method(...)
   	end

    self[methodName] = newMethod
end
function handler(obj, method)
    return function(...)
        if method and obj then
           return method(obj, ...)
        end    
    end
end
function StateBase:doSomething()
	self:bind("getOnceOperationSettle",handler(BehaviorBase,BehaviorBase["getOnceOperationSettle"]))
	self:getOnceOperationSettle("Hello");
	print(self)
end
StateBase:doSomething()