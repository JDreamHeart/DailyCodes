--[[
-- 主要讲解get/set


]]

---设置加载路径
package.path = package.path .. ";../../?.lua;"
require("BYFramework._load")
local Test = class();

local initFunc = function(self)
	local keys = {}
	for k,v in pairs(self) do
		table.insert(keys,k)
	end
	for i,k in ipairs(keys) do
		local uk = string.upperFirst(k)
		local getFunc = function(self)
			return self[k]
		end
		local setFunc = function(self,value)
			self[k] = value
		end
		self["get" .. uk] = getFunc;
		self["set" .. uk] = setFunc;
	end
end

function Test:ctor()
	self.money = 0;
	self.level = 0;
	self.nick  = "";
	-- ....
	self.exp  = 0;

	-- self:initFunc()
	initFunc(self)
end

function Test:initFunc()
	local keys = {}
	for k,v in pairs(self) do
		table.insert(keys,k)
	end
	for i,k in ipairs(keys) do
		local uk = string.upperFirst(k)
		local getFunc = function(self)
			return self[k]
		end
		local setFunc = function(self,value)
			self[k] = value
		end
		self["get" .. uk] = getFunc;
		self["set" .. uk] = setFunc;
	end
end


local t = new(Test);
dump(t)
t:setExp(100)
local money = t:getExp()
print(money)

t.money = 1000 --如果不想直接访问，该怎么办？
local money = t:getMoney()
print(money)