--[[
-- 主要讲解get/set


]]

---设置加载路径
package.path = package.path .. ";../../?.lua;"
require("BYFramework._load")
local Test = class();

function Test:ctor()
	self.money = 0;
	self.level = 0;
	self.nick  = "";
	-- ....
	self.exp  = 0;

	-- self.align = {function ( self )
 --        return self._algin or ALIGN.TOPLEFT
 --    end,function ( self,value )
 --        self._algin = value
 --        self:layout()
 --    end}
end

function Test:setMoney(money)
	self.money = money
end
function Test:getMoney(money)
	return self.money
end

function Test:setLevel(level)
	self.level = level
end
function Test:getLevel(level)
	return self.level
end

local t = new(Test);
dump(t)
t:setMoney(100)
local money = t:getMoney()
print(money)