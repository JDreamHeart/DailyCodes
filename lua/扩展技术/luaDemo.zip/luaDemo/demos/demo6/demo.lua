--[[
-- 引擎篇


]]

package.path = package.path .. ";../../?.lua;"
require("BYFramework._load")

local drawID = -1;
local Node = class();
function Node:ctor( ... )
	self.children = {};
	drawID = drawID + 1;
	self.drawID = drawID;
end

function Node:add(child,zorder)
	table.insert(self.children,child);
end

function Node:remove(child,zorder)
	table.removeByValue(self.children,child)
end

function Node:draw()
	print(self.drawID)
	for k,v in ipairs(self.children) do
		v:draw()
	end
end

local function main( ... )

	local root = new(Node);

	local n = new(Node);
	root:add(n);

	local n2 = new(Node);
	root:add(n2);

	local n3 = new(Node);
	n:add(n3);

	root:draw();
	local ot = 0
	local t = 0;
	-- I/O
	while true do
		root:draw();
		drawcll
		-- t = os.time()
		-- local dt = t - ot
		-- ot  = t;
		-- root:draw(dt);
		-- cur = cur + dt;

	end

end


main()