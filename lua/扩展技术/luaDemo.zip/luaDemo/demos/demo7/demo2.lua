--
-- Author: Your Name
-- Date: 2017-09-06 09:40:49
--

package.path = package.path .. ";../../?.lua;"
require("BYFramework._load")
require("lfs")

-- local function sum(a, b)  
--         return a + b  
-- end  
  
-- local info = debug.getinfo(sum)  
  
-- for k,v in pairs(info) do  
--         print(k, ':', info[k])  
-- end  

function get_dir(dir_path)
	print("111111111111")
    local files = {}
    local dirs = {}
    lfs.dir("")
    for k,v in pairs(lfs.dir("")) do
    	print(k,v)
    end
    -- for f in lfs.dir(dir_path) do
    -- 	print(f)
    --     -- if f ~= '.' and f ~= '..' then
    --     --     if lfs.attributes(dir_path..'/'..f,'mode') == 'file' then
    --     --         if string.upper(string.sub(f,-3))=="LUA" then
    --     --             table.insert(files,string.sub(f,1,string.len(f)-4))
    --     --         end
    --     --     else
    --     --         table.insert(dirs,f.."/")
    --     --     end
    --     -- end
    -- end
    -- return files,dirs
end

require"lfs"  
function findindir (path, wefind, r_table, intofolder)  
    for file in lfs.dir(".") do  
        -- if file ~= "." and file ~= ".." then  
        --     local f = path..'/'..file  
        --     --print ("/t "..f)  
        --     if string.find(f, wefind) ~= nil then  
        --         --print("/t "..f)  
        --         table.insert(r_table, f)  
        --     end  
        --     local attr = lfs.attributes (f)  
        --     assert (type(attr) == "table")  
        --     if attr.mode == "directory" and intofolder then  
        --         findindir (f, wefind, r_table, intofolder)  
        --     else  
        --         --for name, value in pairs(attr) do  
        --         --    print (name, value)  
        --         --end  
        --     end  
        -- end  
    end  
end  


local function main()
	get_dir("C:\\Users\\YuchengMo\\Desktop\\doc\\ppt\\lua\\luaDemo\\")
end

main()