--[[
-- 关于随机


]]

package.path = package.path .. ";../../?.lua;"
require("BYFramework._load")

---随机数,每次运行的数都不一样
local function randomTest()
	local seed = os.time();
	math.randomseed(seed)
    math.random()
    math.random()
    math.random()
    math.random()

    local ret = {}
    for i=1,20 do
    	ret[i] = math.random(100)
    end

    print(table.concat(ret, "  "))
end

---固定随机数
local function test()
	local seed = 1;
	math.randomseed(seed)
    math.random()
    math.random()
    math.random()
    math.random()

    local ret = {}
    for i=1,20 do
    	ret[i] = math.random(100)
    end

    print(table.concat(ret, "  "))
end

local function main( ... )
	randomTest();
	test();


end


main()