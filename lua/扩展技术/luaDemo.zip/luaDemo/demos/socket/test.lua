--struct.pack(">I4BBBBI4HB")
-- Author: Your Name
-- Date: 2017-10-17 10:44:26
--


local msg = [[
1.packet 由什么构成
1122121212121
1
]]

local len,q,e,ver,extend,cmd,gameId,code
-- struct.pack(">I4BBBBI4HB")

require("dump")
require "alien"
require "alien.struct"
require("json")
local struct = alien.struct


local test1 = function()
	local num = 2^8 - 1
	dump(num,"num")
	local buf = struct.pack(">I1",num)
	local ret = struct.unpack(">I1",buf)
	dump(ret)
end


local test2 = function()
	local num = 2^8 - 1
	dump(num,"num")
	local buf = struct.pack(">i1",num)
	local ret = struct.unpack(">i1",buf)
	dump(ret)
end



test1()