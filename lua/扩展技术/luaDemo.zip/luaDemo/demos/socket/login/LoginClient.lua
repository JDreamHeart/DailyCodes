--[[
]]
package.path = package.path .. ";../../../?.lua;"
require("BYFramework._load")


require "alien"
require "alien.struct"
require("json")
local struct = alien.struct
local socket = require("socket")

local CMD = {}

CMD.C2S = {}
CMD.C2S.LOGIN = 0x1001;


local param_data = 
{
    access_token = "",
    action       = "core.login",
    api_ver      = 2,
    app          = 1403000,
    appid        = 1403000,
    channelKey   = "",
    channel_id   = "",
    cmd          = 1,
    guid         = "22",
    hall_version = 820,
    imsi         = "",
    isNew        = 1,
    login_type   = 4,
    mac          = "",
    machine_type = "PC123456",
    mid          = 2462429,
    net          = -1,
    nick         = "PC123456",
    operator     = -1,
    os           = "android_4.0.0",
    param        = "{\"imsi\":\"\",\"safecode_guid\":\"\",\"iccid\":\"\",\"factoryid\":\"\",\"bundleId\":\"\",\"safecode\":\"\",\"update_site_realtime\":1,\"timestamp\":1507799660,\"imei\":\"\",\"safecode_mac\":\"\"}",
    phone        = "",
    pwd          = "",
    resolution   = "1280*720",
    secret       = "86586f83bcb900ee0f9ae3c44422659c",
    seq          = 2,
    sex          = 0,
    sig          = "119d8eebd8976e70798c342b1a0893d0",
    ssid         = "",
    timestamp    = 1507799660,
    utype        = 1,
    verify_code  = -1,
    verify_msg   = "",
    verify_word  = "",
    version      = "3.3.0.0",
}

-- local param_data = 
-- {
--     access_token = "",
--     action       = "core.login",
--     api_ver      = 2,
--     app          = 1403000,
--     appid        = 1403000,
--     channelKey   = "",
--     channel_id   = "",
--     cmd          = 1,
--     guid         = "123445566",
--     hall_version = 820,
--     imsi         = "",
--     isNew        = 1,
--     login_type   = 4,
--     mac          = "",
--     machine_type = "PC123456",
--     mid          = 2462429,
--     net          = -1,
--     nick         = "PC123456",
--     operator     = -1,
--     os           = "android_4.0.0",
--     param        = "{\"imsi\":\"\",\"safecode_guid\":\"\",\"iccid\":\"\",\"factoryid\":\"\",\"bundleId\":\"\",\"safecode\":\"\",\"update_site_realtime\":1,\"timestamp\":1507799660,\"imei\":\"\",\"safecode_mac\":\"\"}",
--     phone        = "",
--     pwd          = "",
--     resolution   = "1280*720",
--     secret       = "86586f83bcb900ee0f9ae3c44422659c",
--     seq          = 2,
--     sex          = 0,
--     sig          = "dc2556e9093beb9b7d30e515b4f6b060",
--     ssid         = "",
--     timestamp    = 1507799660,
--     utype        = 1,
--     verify_code  = -1,
--     verify_msg   = "",
--     verify_word  = "",
--     version      = "3.3.0.0",
-- }

function getSig(data)
    local keys = {};
    for k,v in pairs(data) do
        table.insert(keys,k)
    end

    table.sort(keys,function(a,b)
        return a < b
    end);

    local ret = {}
    for i,v in ipairs(keys) do
        table.insert(ret,v .. ":" .. data[v]);
    end
    ret = table.concat(ret,",")
    ret = ret .. "_" .. data.timestamp
    dump(ret,"sig")
    dump(#ret,"sig")
    require"md5"
    ret = md5.sumhexa(ret)
    dump(ret,"sig")
    return ret
end




local function main()

    local host = "127.0.0.1"
    local port = 8889
    local sock = assert(socket.connect(host, port))
    sock:settimeout(0)


    local getLoginData = function(input)
        local data = clone(param_data);
        data.guid = input;
        -- data.sig = nil;
        -- data.sig = getSig(data);
        -- dumpToFile("loginData",data)
        return json.encode(data)
    end

    local input, recvt, sendt, status
    while true do
        print("input guid ")
        input = io.read()
        if #input > 0 then
            if input == "110" then
                break;
            end
            local loginData = getLoginData(input)
            local body_buf = struct.pack('>I4s', #loginData, loginData)
            local head_buf = struct.pack(">I4I4I1",#body_buf+5,CMD.C2S.LOGIN,1) ---0x1001登陆
            local buf = head_buf .. body_buf
            assert(sock:send(buf))
            dump(#buf,"totalLen")

        end
        recvt, sendt, status = socket.select({sock}, nil, 1)
        while #recvt > 0 do
            local response, receive_status = sock:receive()
            if receive_status ~= "closed" then
                if response then
                    print(response)
                    recvt, sendt, status = socket.select({sock}, nil, 1)
                end
            else
                break
            end
        end
    end
    sock:close();

end

-- main()



local ret = getSig(param_data)
-- dump(ret,"ret")
dump(ret,"ret")