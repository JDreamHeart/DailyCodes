-- server.lua
local socket = require("socket")
require("dump")
require "alien"
require "alien.struct"
require("json")
local struct = alien.struct

local host = "127.0.0.1"
local port = "8000"
local server = assert(socket.bind(host, port, 1024))
server:settimeout(0)
local client_tab = {}
local conn_count = 0
 
print("Server Start " .. host .. ":" .. port) 


local onRecv = function(sock)

    ---处理包头
    local buf, receive_status = sock:receive(15)
    if receive_status == "closed" then
        return receive_status;
    end
    local len,q,e,ver,extend,cmd,gameId,code,position
    position = 1
    len,q,e,ver,extend,cmd,gameId,code,position = struct.unpack('>I4BBBBI4HB',buf,position)
    dump(string.format("0x%x",cmd),len)

    local bodyLen = len - 11;
    local buf, receive_status = sock:receive(bodyLen)
    if receive_status == "closed" then
        return receive_status;
    end
    position = 1;
    local t = {};
    t.mid,position      = struct.unpack('>I4',buf,position);
    t.money,position    = struct.unpack('>I4',buf,position);
    t.level,position    = struct.unpack('>I4',buf,position);
    t.exp,position      = struct.unpack('>I4',buf,position);
    t.seat,position     = struct.unpack('>I4',buf,position);

    dump(position,"position")
    dump(#buf,"buf")
    local jsonLen,position = struct.unpack('>I4',buf,position);
    t.jsonStr,position = struct.unpack('>c' .. tostring(jsonLen),buf,position);
    position = position + 1 ---为什么要加1？？？？？？？
    dump(t,"cmd")

    return t,receive_status

end

while 1 do

    local conn = server:accept()
    if conn then
        conn_count = conn_count + 1
        client_tab[conn_count] = conn
        print("A client successfully connect!") 
    end
  
    for conn_count, client in pairs(client_tab) do
        local recvt, sendt, status = socket.select({client}, nil, 1)
        if #recvt > 0 then
            local receive, receive_status = onRecv(client)
            if receive_status ~= "closed" then
                local ret = json.encode(receive)
                client:send(ret .. "\n");
            else
                table.remove(client_tab, conn_count) 
                client:close() 
                print("Client " .. conn_count .. " disconnect!") 
            end
        end
         
    end
end