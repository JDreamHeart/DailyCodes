--[[
一、为什么会出现大小端模式？
不同的cpu采用的大小端模式不一致。X86是小端模式。而KEIL C51则为大端模式。
很多的ARM，DSP都为小端模式。有些ARM处理器还可以由硬件来选择是大端模式还是小端模式。

二、大小端模式的不同带来的问题是什么？如何解决？
如果存在数据网络传输，如果大小端模式不一致，如果不经过转换，必然会导致数据不致，出现错误。
解决方法：统一将网络上传输的字节序采用同一种模式（大家都知道的），这样收发数据时，
就会根据主机对应的模式是否和网络字节对应的模式一致，来判断是否需要进行转换。
这样即使不同的设备使用不同的模式，网络传输不会出现问题。

四、网络字节序
由于不同的系统会有不同的模式，为了统一，
规定在网络传输中使用大端模式，这就是网络字节序。现在看看下面这四个函数的作用


用于 string.pack， string.packsize， string.unpack 的第一个参数。 它是一个描述了需要创建或读取的结构之布局。

格式串是由转换选项构成的序列。 这些转换选项列在后面：

<: 设为小端编码
>: 设为大端编码
=: 大小端遵循本地设置
![n]: 将最大对齐数设为 n （默认遵循本地对齐设置）
b: 一个有符号字节 (char)
B: 一个无符号字节 (char)
h: 一个有符号 short （本地大小）
H: 一个无符号 short （本地大小）
l: 一个有符号 long （本地大小）
L: 一个无符号 long （本地大小）
j: 一个 lua_Integer
J: 一个 lua_Unsigned
T: 一个 size_t （本地大小）
i[n]: 一个 n 字节长（默认为本地大小）的有符号 int
I[n]: 一个 n 字节长（默认为本地大小）的无符号 int
f: 一个 float （本地大小）
d: 一个 double （本地大小）
n: 一个 lua_Number
cn: n字节固定长度的字符串
z: 零结尾的字符串
s[n]: 长度加内容的字符串，其长度编码为一个 n 字节（默认是个 size_t） 长的无符号整数。
x: 一个字节的填充
Xop: 按选项 op 的方式对齐（忽略它的其它方面）的一个空条目
' ': （空格）忽略
（ "[n]" 表示一个可选的整数。） 除填充、空格、配置项（选项 "xX <=>!"）外， 每个选项都关联一个参数（对于 string.pack） 或结果（对于 string.unpack）。

对于选项 "!n", "sn", "in", "In", n 可以是 1 到 16 间的整数。 所有的整数选项都将做溢出检查； string.pack 检查提供的值是否能用指定的字长表示； string.unpack 检查读出的值能否置入 Lua 整数中。

任何格式串都假设有一个 "!1=" 前缀， 即最大对齐为 1 （无对齐）且采用本地大小端设置。

对齐行为按如下规则工作： 对每个选项，格式化时都会填充一些字节直到数据从一个特定偏移处开始， 这个位置是该选项的大小和最大对齐数中较小的那个数的倍数； 这个较小值必须是 2 个整数次方。 选项 "c" 及 "z" 不做对齐处理； 选项 "s" 对对齐遵循其开头的整数。

string.pack 用零去填充 （string.unpack 则忽略它）。

]]

local function main()
    local socket = require("socket")
    local host = "127.0.0.1"
    local port = 8000
    local sock = assert(socket.connect(host, port))
    sock:settimeout(5)
    require("dump")
    require "alien"
    require "alien.struct"
    require("json")
    local struct = alien.struct

    getLoginData = function()
        local data = {};
        data.guid = 1;
        return json.encode(data)
        -- return data;
    end

    local input, recvt, sendt, status
    while true do
        print("input cmd")
        input = io.read()
        if #input > 0 then
            if input == "1" then
                print(input)
                local head_buf = struct.pack(">I4BBBBI4HB",20+11,string.byte('Q'),string.byte('E'),1,0,0x602d,1,1)
                local mid = 10001;
                local money = 100;
                local level = 12;
                local exp = 10000;
                local seat = 1;
                -- WriteInt(value)
                local body = struct.pack(">I4I4I4I4I4",mid,money,level,exp,seat)
                local loginData = getLoginData()
                if loginData then
                    dump(loginData)
                    local jsonBuf = struct.pack('>I4s', #loginData, loginData)
                    body = body .. jsonBuf;

                    local jsonBuf = struct.pack('>I4s', #loginData, loginData)
                    body = body .. jsonBuf;

                end
                local head_buf = struct.pack(">I4BBBBI4HB",#body+11,string.byte('Q'),string.byte('E'),1,0,0x602d,1,1)
                local buf = head_buf .. body
                assert(sock:send(buf))
                dump(#buf,"totalLen")
            else
                print("input error")
            end

        end
        recvt, sendt, status = socket.select({sock}, nil, 1)
        while #recvt > 0 do
            local response, receive_status = sock:receive()
            if receive_status ~= "closed" then
                if response then
                    print(response)
                    recvt, sendt, status = socket.select({sock}, nil, 1)
                end
            else
                break
            end
        end

    end

end

main()

